<template>
  <home></home>
</template>
<script>
import Home from "@/pages/Home"
export default {
  name: "App",
  components: {
    Home
  }
};
</script>
<style lang="stylus" scoped>
</style>

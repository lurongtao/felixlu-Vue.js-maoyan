<template>
  <div class="btn">
    <span class="fix" data-bid="dp_wx_home_movie_btn">
      <slot></slot>
    </span>
  </div>
</template>
<script>
export default {
  name: 'MovieItemButton'
}
</script>
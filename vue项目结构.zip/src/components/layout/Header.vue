<template>
  <header>猫眼电影</header>
</template>
<script>
export default {

}
</script>
<style lang='stylus' scoped>
@import '~styles/variables.styl'
header
  height .5rem
  background $base-color
  font-size .18rem
  line-height .5rem
  text-align center
  color #fff
  font-weight 100
</style>
